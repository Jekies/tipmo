﻿# Build An Awesome Landing Page in ReactJS & TailwindCSS! 
![alt text](https://github.com/TECHCROWDMY/practice-landing-page/blob/main/cover.jpg?raw=true)


1. Clone the repository.
2. Run npm install command.     ```npm install```
3. Run npm run dev.     ```npm run dev```






